# UPA 13 - Aplicativo Android

Projeto Android pronto para gerar o APK pelo GitHub Actions.

O aplicativo abre a versão celular do UPA 13 dentro de um WebView e usa o
Google Apps Script configurado para sincronização:

https://script.google.com/macros/s/AKfycby5_WHjbtNNnGcSFl6JtcZBa4dkOjRpH23HzTzaYGqQeycAin_nrmvI-_9xk6XVp8Ct/exec

## Gerar o APK no GitHub

1. Crie/abra um repositório no GitHub.
2. Envie TODO o conteúdo deste projeto para a raiz do repositório.
3. Abra a aba **Actions**.
4. Abra **Gerar APK UPA 13**.
5. Toque em **Run workflow**.
6. Quando terminar, abra a execução e baixe o artefato **UPA13-APK**.
7. Dentro dele estará o arquivo **app-debug.apk** para instalar no Android.

Importante: o APK contém o app celular, mas os dados continuam sendo
atualizados pela internet através do servidor do Google Apps Script.


## Correção desta versão

- Atualizado para o servidor Apps Script mais recente.
- O aplicativo migra automaticamente endereços antigos salvos no WebView.
- Se o Android recusar instalar por conflito de assinatura de um APK debug anterior, desinstale a versão antiga e instale esta nova. Os dados online voltam a sincronizar ao abrir.
