UPA 13 - GERAR APK PELO GITHUB

Este projeto já está preparado para compilar o APK automaticamente pelo GitHub Actions.

PASSOS:
1. Crie um repositório novo no GitHub.
2. Envie TODO o conteúdo desta pasta para a raiz do repositório.
   É importante que as pastas "app" e ".github" fiquem na raiz.
3. Abra a aba "Actions" do repositório.
4. Abra o workflow "Gerar APK UPA13".
5. Toque em "Run workflow" e confirme.
6. Quando terminar com sucesso, abra a execução.
7. Na área "Artifacts", baixe "UPA13-APK".
8. Extraia o arquivo baixado e instale "app-debug.apk" no Android.

O workflow também roda automaticamente quando houver alterações enviadas para as branches main ou master.

CONFIGURAÇÃO USADA:
- Java 17
- Gradle 8.2
- Android Gradle Plugin 8.2.2
- compileSdk 34
- minSdk 24
- targetSdk 34

Arquivo do workflow:
.github/workflows/build-apk.yml
