UPA 13 - Android App
Versao 1.1.0

O aplicativo abre primeiro a versao online publicada no Google Apps Script:
https://script.google.com/macros/s/AKfycbyARm6y7OzQy1I-awNouMC9m0rHrujRxMpmeuQP0oM_nYr6eIKFzeyHsbOqL-u__WJ5CQ/exec

Assim, alteracoes publicadas no programa online aparecem no celular quando ele estiver conectado a internet, sem precisar reinstalar o APK.
Se a pagina online falhar ao abrir, o aplicativo usa automaticamente a copia local em app/src/main/assets/index.html.

Para gerar o APK no AndroidIDE: abra esta pasta como projeto Gradle, sincronize e use Build > Assemble Debug.
APK esperado: app/build/outputs/apk/debug/app-debug.apk
