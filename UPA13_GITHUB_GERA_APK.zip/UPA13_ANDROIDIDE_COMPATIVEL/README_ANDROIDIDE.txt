UPA 13 - PROJETO COMPATIVEL COM ANDROIDIDE

1. Extraia esta pasta no armazenamento do celular.
2. No AndroidIDE, abra a pasta UPA13_ANDROIDIDE_COMPATIVEL.
3. Aguarde a sincronizacao do Gradle.
4. Execute Assemble Debug.
5. APK esperado: app/build/outputs/apk/debug/app-debug.apk

Configuracao ajustada para maior compatibilidade:
- Android Gradle Plugin 8.2.2
- compileSdk 34
- targetSdk 34
- Java 17

O app abre a versao online da UPA 13 e usa a copia local se a internet falhar.
