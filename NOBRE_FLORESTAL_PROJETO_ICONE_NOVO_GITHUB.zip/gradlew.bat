@echo off
setlocal
set GRADLE_VERSION=8.9
where gradle >nul 2>&1
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle nao encontrado no Windows. Use o GitHub Actions para gerar o APK.
exit /b 1
